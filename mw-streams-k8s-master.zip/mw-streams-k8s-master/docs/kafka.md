## kafka namespace

### kafka

```bash
# access kafka
kubectl exec -it kafka-cluster-kafka-0 -n kafka -- bash

# list topics
bin/kafka-topics.sh --list --zookeeper localhost:2181

# list consumer groups
bin/kafka-consumer-groups.sh \
  --bootstrap-server kafka-cluster-kafka-bootstrap.kafka:9092 \
  --list

# retrieve current offset
bin/kafka-consumer-groups.sh \
  --bootstrap-server kafka-cluster-kafka-bootstrap.kafka:9092 \
  --group MY_CONSUMER_GROUP \
  --describe

# reset offset
bin/kafka-consumer-groups.sh \
  --bootstrap-server kafka-cluster-kafka-bootstrap.kafka:9092 \
  --group MY_CONSUMER_GROUP \
  --topic MY_TOPIC \
  --reset-offsets \
  --to-earliest \
  --execute
```

### schema-registry

```bash
# access schema-registry
kubectl exec schema-registry-cp-schema-registry-XXX -c cp-schema-registry-server -it bash -n kafka

# enable access to the schema-registry-ui service
kubectl port-forward svc/schema-registry-cp-schema-registry 8081:8081 -n kafka

# list of registered subjects
curl localhost:8081/subjects

# delete specified subject 
curl -X DELETE localhost:8081/subjects/MY_SCHEMA
```

### kafka-connect

```bash
# access kafka-connect
kubectl exec kafka-connect-cp-kafka-connect-XXX -c cp-kafka-connect-server -it bash -n kafka

# consume avro topics
kafka-avro-console-consumer \
  --bootstrap-server kafka-cluster-kafka-bootstrap.kafka:9092 \
  --property schema.registry.url="http://schema-registry-cp-schema-registry:8081" \
  --topic MY_TOPIC \
  --from-beginning

# list connectors
curl localhost:8083/connectors

# get information about the connector
curl localhost:8083/connectors/MY_CONNECTOR

#delete a connector
curl -X DELETE localhost:8083/connectors/MY_CONNECTOR
```

### kafka-topic-ui

```bash
# sync kafka-rest and kafka-topic-ui ArgoCD applications
argocd app sync kafka-rest
argocd app sync kafka-topic-ui

# enable access to the kafka-topic-ui service
kubectl port-forward svc/kafka-topic-ui -n kafka 8084:80

# open kafka-topic-ui
http://localhost:8084
```

### kafka-connect-ui

```bash
# sync kafka-connect-ui ArgoCD application
argocd app sync kafka-connect-ui

# enable access to the kafka-connect-ui service
kubectl port-forward svc/kafka-connect-ui -n kafka 8085:80

# open kafka-connect-ui
http://localhost:8085
```

### schema-registry-ui

```bash
# sync schema-registry-ui ArgoCD application
argocd app sync schema-registry-ui

# enable access to the schema-registry-ui service
kubectl port-forward svc/schema-registry-ui -n kafka 8086:80

# open schema-registry-ui
http://localhost:8086
```

### kafkacat

```bash
# sync kafkacat ArgoCD application
argocd app sync kafka-cat

# access kafkacat
kubectl exec -it kafkacat-XXX -n kafka -- sh
```
[kafkacat examples](https://github.com/edenhill/kafkacat#examples)

