## Argo CD

### Private repository

To setup a [private GitHub repository](https://argoproj.github.io/argo-cd/user-guide/private-repositories) on Argo CD 

1) [Generate a new SSH key pair](https://help.github.com/en/articles/generating-a-new-ssh-key-and-adding-it-to-the-ssh-agent#generating-a-new-ssh-key)

```bash
# generate ssh keys
ssh-keygen -t rsa -b 4096 -C "argocd-hbc-integration@hbc.com" -N '' -f /tmp/id_rsa_hbc

# wrap private key in json format
jq --raw-input --slurp "{sshPrivateKey: .}" /tmp/id_rsa_hbc -c > /tmp/id_rsa_hbc.json
```

2) Add the public key to the list of [deploy keys](https://developer.github.com/v3/guides/managing-deploy-keys/#deploy-keys) on a GitHub repository

```bash
# copy public key
pbcopy < /tmp/id_rsa_hbc.pub

# title (read access only)
# eks/argocd/deploy-key/github.com/saksdirect/<REPOSITORY_NAME>
```

3) Add the private key to AWS Secret Manager (requires Okta login)

```bash
export AWS_REGION=us-east-1
export AWS_PROFILE=hbc-integration
# example "mw-streams-k8s"
export REPOSITORY_NAME=<REPOSITORY_NAME>

# list secrets
aws secretsmanager list-secrets | jq '.SecretList[].Name'

# create secret
aws secretsmanager create-secret \
  --name "eks/argocd/deploy-key/github.com/saksdirect/$REPOSITORY_NAME" \
  --description "GitHub deploy key of saksdirect/$REPOSITORY_NAME" \
  --secret-string file:///tmp/id_rsa_hbc.json

# verify secret
aws secretsmanager describe-secret \
  --secret-id "eks/argocd/deploy-key/github.com/saksdirect/$REPOSITORY_NAME"

# retrieve secret
aws secretsmanager get-secret-value \
  --secret-id "eks/argocd/deploy-key/github.com/saksdirect/$REPOSITORY_NAME" \
  --version-stage AWSCURRENT | jq -r '.SecretString | fromjson | .sshPrivateKey'
```

4) Cleanup

```bash
# delete key pair
rm -fr /tmp/id_rsa_hbc*
```

5) Verify or update the ConfigMap `argocd-ssh-known-hosts-cm` with [SSH known host public keys](https://argoproj.github.io/argo-cd/operator-manual/declarative-setup/#ssh-known-host-public-keys) (first time only)

```bash
# derive public key of known host
ssh-keyscan -t rsa github.com
```

6) Add an `AWSSecret` custom resource to [`argocd-secrets.yaml`](/charts/aws-secrets/templates/argocd-secrets.yaml)

```bash
# retrive AWSCURRENT secret version id
aws secretsmanager describe-secret \
  --secret-id "eks/argocd/deploy-key/github.com/saksdirect/$REPOSITORY_NAME"
```

Example
```yaml
---
apiVersion: mumoshu.github.io/v1alpha1
kind: AWSSecret
metadata:
  name: github-saksdirect-mw-REPOSITORY_NAME
  namespace: argocd
spec:
  stringDataFrom:
    secretsManagerSecretRef:
      secretId: SECRET_NAME
      versionId: AWSCURRENT_VERSION_UUID
```

7) Add the repository to the [`argocd-cm`](/charts/argocd-config/values-repositories.yaml) ConfigMap

Example
```yaml
argocd:
  config:
    repositories:
      # ...
      - url: git@github.com:saksdirect/mw-REPOSITORY_NAME.git
        sshPrivateKeySecret:
          key: sshPrivateKey
          name: github-saksdirect-mw-REPOSITORY_NAME
```

8) Add the repository to the corresponding AppProject (applications/templates/<YOUR_PROJECT>/project.yaml) sourceRepos:

Example

```yaml
---
apiVersion: argoproj.io/v1alpha1
kind: AppProject
metadata:
  name: <PROJECT_NAME>
spec:
  # ...
  sourceRepos:
    # ...
    - git@github.com:saksdirect/REPOSITORY_NAMe.git
```

### Public repository
1) Only add the repository to the corresponding AppProject (applications/templates/<YOUR_PROJECT>/project.yaml) sourceRepos:

Example

```yaml
---
apiVersion: argoproj.io/v1alpha1
kind: AppProject
metadata:
  name: <PROJECT_NAME>
spec:
  # ...
  sourceRepos:
    # ...
    - https://github.com/saksdirect/REPOSITORY_NAME.git
```

### FAQ

#### *How can I access to ArgoCD?*

There is a DNS entry for ArgoCD to each environment. To access to ArgoCD you should log into AppGate first.

```bash
https://argocd.eks.<ENVIRONMENT>.streams.integration.aws
```
For instance, if you want to access ArgoCD application of dev-tmp-1 cluster, you should replace ENVIRONMENT value with the cluster name.

```bash
https://argocd.eks.dev-tmp-1.streams.integration.aws
```
Some urls:

[https://argocd.eks.dev.streams.integration.awshbc.io/](https://argocd.eks.dev.streams.integration.awshbc.io/)
[https://argocd.eks.prod.streams.integration.awshbc.io/](https://argocd.eks.prod.streams.integration.awshbc.io/)


What about if you want to use ArgoCD from the CLI? Well, you must be authenticated first. Below an example how to accomplish that.

```bash
argocd login argocd.eks.dev-tmp-1.streams.integration.awshbc.io:443 --insecure
```

#### *How to test an Application from a branch?*

Sometimes, mostly during the development, you might need to test your branch before opening a PR. The simplest way to do this is from the UI. You can either point the Application of Applications or a single Application to a specific *target revision*. Argo CD will take care of deleting the old resources and re-create them pointing to a specific branch or commit.

<p align="center">
  <img src="img/target-revision.png" alt="target-revision">
</p>

#### *How to fix an Argo CD cluster resource issue?*

One of the most common issues when deploying an Application with Argo CD is for it not to be able to access certain cluster resources. The error in the UI looks like this

<p align="center">
  <img src="img/resource-permission-issue.png" alt="resource-permission-issue">
</p>

e.g. to fix the error `Resource apiextensions.k8s.io:CustomResourceDefinition is not permitted in project observe.` you must edit the `AppProject` adding

```yaml
---
apiVersion: argoproj.io/v1alpha1
kind: AppProject
metadata:
  name: observe
spec:
  # ...
  clusterResourceWhitelist:
    # ...
    - group: apiextensions.k8s.io
      kind: CustomResourceDefinition
```

#### *How to fix an Argo CD namespace issue?*

If the Application needs access to resources in a different namespace, you may see an error like this

<p align="center">
  <img src="img/destination-permission-issue.png" alt="resource-permission-issue">
</p>

e.g. to fix the error `namespace kube-system is not permitted in project 'observe'` you must edit the `AppProject` adding

```yaml
---
apiVersion: argoproj.io/v1alpha1
kind: AppProject
metadata:
  name: observe
spec:
  # ...
  destinations:
    # ...
    - namespace: kube-system
      server: https://kubernetes.default.svc
```

#### *How to fix an Argo CD repository issue?*

When you point to a Chart, Argo CD requires you to whitelist the repositories where the sources are hosted, otherwise you might have an error like this

<p align="center">
  <img src="img/repository-permission-issue.png" alt="repository-permission-issue">
</p>

e.g. to fix the error `application repo https://github.com/elastic/helm-charts.git is not permitted in project 'observe'` you must edit the `AppProject` adding

```yaml
---
apiVersion: argoproj.io/v1alpha1
kind: AppProject
metadata:
  name: observe
spec:
  # ...
  sourceRepos:
    # ...
    - https://github.com/elastic/helm-charts.git
```
#### *What ArgoCD projects do we have now?*
Projects provide a logical grouping of applications, which is useful when Argo CD is used by multiple teams. In our context one project restrict where apps may be deployed to (destination clusters and namespaces)
Every application belongs to a single project.
Every project has a corresponding AppProject (applications/templates/<YOUR_PROJECT>/project.yaml)
We are using the following projects:
* argocd
* default
* [kafka](https://github.com/saksdirect/mw-streams-k8s/tree/master/applications/templates/kafka) 
* [streams](https://github.com/saksdirect/mw-streams-k8s/tree/master/applications/templates/streams)
* [streams-ddw](https://github.com/saksdirect/mw-streams-k8s/tree/master/applications/templates/streams-ddw)
* [kube-aws](https://github.com/saksdirect/mw-streams-k8s/tree/master/applications/templates/kube-aws)
* [observe](https://github.com/saksdirect/mw-streams-k8s/tree/master/applications/templates/observe)

