## AppGate


## Overview and Client Installation
AppGate is a security gateway that provides segmented access to EC2 and application services in AWS. Access to endpoints running in AWS will require starting the AppGate client.  However, it is still possible to execute kube proxy against services in you cluster and access the services locally.

[Client installation instructions](
https://docs.google.com/document/d/1EkXdiZAAykAhWSV1uAux0dJbVIkyEWLndwYsZpHAYmo/edit#heading=h.bi8g6lnepx0w)

The Cisco VPN client and the AppGate client **CANNOT** be executed at the same time.  Both clients attempt to manage your local route table and continously terminate each other.

The AppGate client **MUST** be used to access AWS services as well as internal HBC websites.  It cannot be used to ssh to hbc hosts. 

**OF NOTE**:  You **MUST** log into the AppGate client to access an EC2 instance or http endpoint (such as an ELB) in the hbc-integtation account.  Even when you are connected to the HBC network at an office.

AppGate supports split tunnelling and does not disrupt your LAN or route your LAN traffic.  If you are logged into the HBC LAN, you can simultaneously access HBC resources along with AppGate protected AWS resources. If you are logged into any other LAN, you can still access resources through that network and AppGate accessible resources.

## Authorizing Access To AppGate In Okta
Granting a new user network access to the mw streams team VPC ip addresses only requires adding the user’s Okta profile to the Okta group **appgate-mw-streams-k8s**.  Adding a user to this group will grant access to the **hbc-integration** AWS accounts console and cli, AppGate authorization to access the VPC endpoints and access to the JFrog SaaS service.  Anyone can request this access by opening a ticket on the [Jira Infrastructure Kanban Board](https://hbcdigital.atlassian.net/secure/RapidBoard.jspa?rapidView=278) requesting the user (include the user’s email) be added to the Okta group **appgate-mw-streams-k8s**.


#### Updating AppGate Access to AWS VPC Resources
These are operations instructions for users with Organizational Administrator access in Okta and Admin access in AppGate.

The AppGate Policy that controls which Okta groups have access to the mw streams VPC ip addresses is named **mw-streams-k8s**.  The AppGate Entitlement containing the ip/endpoint addresses in the hbc-integration account belonging to the mw streams project is also named **mw-streams-k8s**.  If an ip address, or http endpoint resource is *NOT* added to the Entitlement, then the resource will *NOT* be accessible...from any network.
