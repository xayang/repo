## ArgoCD Authentication

ArgoCD resources are restricted based on RBAC controls driven by authentication credentials taken from an *Okta Open ID Connect* (OIDC) provider.  The following outlines:

1. [Configure an OIDC Application in Okta (admin only)](#configure-an-oidc-application-in-okta)
2. [Configure OIDC Connectivity in ArgoCD](#configure-oidc-connectivity-in-argocd)
3. [Configure Roles in ArgoCD](#configure-roles-in-argocd)
4. [Configure CLI Connectivity through Okta](#configure-cli-connectivity-through-okta)


### Configure OIDC Connectivity in ArgoCD
An Okta OIDC application supports multiple login redirect URIs allowing us to share a single Okta application with multiple clients.  A single OIDC application is configured per environment type which are:

* `dev` development
* `prod` production

*development environments* - Application named: mw-streams-k8s-dev

*production environments* - Application named: mw-streams-k8s-prod

Open https://hbctech-admin.okta.com/admin/apps/active and search for the application name.  Open the tab named **General** and the section labeled **Client Credentials**.  There you will find two values needed to configure ArgoCD:  *Client ID*  and *Client secret*

We are using each application for an entire class of ArgoCD instances (e.g. all development instances use the development app).  Therefore we only need to set the following values once per environment type:

1. *Client ID*:   Stored in the Secrets Manager of the hbc-integration AWS account under the key **eks/okta/oidc/mw-streams-k8s/[env]/clientid** where [env] is either **prod**, or **dev**.  The [env] value is derived from the **env** environment variable supplied to the **scripts/bootstrap.sh** and passed to the bootstrap chart as a *set* value.

2. *Client Secret*:  Stored in the Secrets Manager of the hbc-integration AWS account under the key **eks/okta/oidc/mw-streams-k8s/[env]/clientsecret** where [env] is either **prod**, or **dev**.  The [env] value is derived from the **env** environment variable supplied to the **scripts/bootstrap.sh** and passed to the bootstrap chart as a *set* value.

3. *Login Redirect URIs*:  This is the URI the OIDC application calls back with authentication request results.  You must register your specific ArgoCD endpoint with the environment specific OIDC application.  The value for the URI is derived as part of the bootstrap process.  The redirect URI will have the format **[argocd-full-domain]/auth/callback**.  The boostrapped application automatically creates an **[argocd-full-domain]** endpoint, registered in Route 53 and having the naming format: **argocd-mw-streams-k8s-[env].integration.awshbc.io** where [env] is the value of the environment variable set before the **make cluster-create** call (and sent to the **scripts/bootstrap.sh** script as a command line argument.)  The [env] value  **MUST** be one of the values: 

* dev
* dev-tmp-1
* dev-tmp-2
* dev-tmp-3
* prod


As an example: If the [env] value is set to *dev-tmp-1* the redirect URI will be *argocd.eks.dev-tmp-1.streams.integration.awshbc.io/auth/callback*.  In this case, the development OIDC application, under the *LOGIN* section would have a *Login redirect URIs* entry that looks like:
![](img/okta-oidc-redirecturi-example.png)


### Configure Roles in ArgoCD
ArgoCD [RBAC](https://argoproj.github.io/argo-cd/operator-manual/rbac/) controls are configured in the [argocd.yaml](../applications/templates/argocd/argocd.yaml) file under the parameter **rbac.policyCsv**. The default configuration assigns the admin role to any user that is assigned the Okta role **appgate-mw-streams-k8s**.  All other users have readonly permissions.

### Configure an OIDC Application in Okta
If a new OIDC environment type is needed use the following steps to create the application in Okta (you must have "Application Administrator" permission in Okta) and then configure the "Client ID" and "Client secret" values according to [Configure OIDC Connectivity in ArgoCD](#configure_oidc_connectivity_in_argocd).

1. In the top navigation select "Applications -> Applications" and click the "Add Application" options.
![](img/okta-oidc-create-1.png)

2. Click the "Create New App" option and select the fields listed below, then click create.
![](img/okta-oidc-create-2.png)

3. On the "Create OpenID Connection Integration" screen, set the "Application Name" to the format **mw-streams-k8s-[environment-name]**.  Set the "Login redirect URIs" to the format **https://argocd-mw-streams-k8s-[environment-name].integration.awshbc.io/auth/callback**.  Then click save.
![](img/okta-oidc-create-3.png)

At this point, every user with valid Okta credentials can successfully authenticate against the application.  You can further restrict access by setting the "Sign On Policy" in the "Sign On" section of the applicaton.  For example, only allow user assigned to a specify gropu to be access the application.

4. Add the application to an *Administrator Group*.  This must be performed by a user that has *Organization* administration access.  As an Organization administrator navigate to **Security -> Administrators** and click the **GROUP** entry under **ADMIN TYPES** in the left hand side.  Click the *pencil* icon to edit the group. in the *Edit Administrator*  screen at the bottom, add the name of your new application.  This grants all users in the **appgate-mw-streams-k8s** Okta group access to modify the application.

Screen to select the Application Administrator:
![](img/okta-app-admin-add-1.png)


Screen to add new OIDC application:
![](img/okta-app-admin-add-2.png)

### Configure CLI Connectivity through Okta
When the "argocd login" command is launched with the flag **--sso**, a temporary web server is opened on localhost:8085 as the callback handler post Okta authentication.  You will need to add **https://localhost:8085/auth/callback** to your Okta OIDC provider application to enable posting back authentiation claims from Okta to this local server.  

Open your Okta OIDC application and select the *General* section.  Then add **https://localhost:8085/auth/callback** as a "Login redirect URI" entry in the **Login** section.  The following is the configuration for the **mw-streams-k8s-dev** application:

![](img/okta-oidc-create-4.png)

Once configured, you can make an login call to your ArgoCD UI either directly our through a kube proxy.  Command line format:

```
argocd login [localhost or FQDN to ArgoCD UI] --sso --insecure
```

Example using a FQDN for the UI service:
```
argocd login argocd-mw-streams-k8s-dev.integration.awshbc.io:443 --sso --insecure
```

A browser window will be opened to hbctech.okta.com where you can login with your Okta user/password credentials.

**OF NOTE**:  The argocd cli maintains a credentials to server host context similar to kubectl. This means you must access the argocd service at the same endpoint you used to login.  If you login with the FQDN of the UI, your credentials will not be valid when accessing the UI at *https://localhost:8080*.

> TODO

If you can't connect try to verify `dig argocd.eks.dev-tmp-2.streams.integration.awshbc.io +short`
