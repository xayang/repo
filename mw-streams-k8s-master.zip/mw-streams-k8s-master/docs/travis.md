## Travis

* [gilt-okta-aws-login](https://github.com/saksdirect/gilt-okta-aws-login)
* [Encryption keys](https://docs.travis-ci.com/user/encryption-keys)

```bash
# login to aws
okta-aws-login --user <USERNAME> --keep-reloading --aws-profile hbc-integration

# create ECR repository
# repository is created in the hbc-integration account e.g. "hbc-integration/mw-inventory"
make ecr-create repository=mw-REPOSITORY_NAME

# list images
make ecr-list-images repository=mw-REPOSITORY_NAME

# retrieve Travis secrets from SSM to access ECR
aws secretsmanager get-secret-value \
  --region "us-east-1" \
  --profile "hbc-integration" \
  --secret-id "phoenix/travisci/iam-credentials" \
  --version-stage AWSCURRENT | jq -r '.SecretString'

# install/update cli
gem install travis

# login to travis (travis-ci.com)
travis login --pro --auto

# add encrypted secrets to .travis.yml
travis encrypt AWS_ACCESS_KEY_ID=<AWS_ACCESS_KEY_ID> --add
travis encrypt AWS_SECRET_ACCESS_KEY=<AWS_SECRET_ACCESS_KEY> --add

# print encrypted secrets
travis encrypt <NAME>=<VALUE> -r owner/project --pro
```

Policies attached to `phoenix-travis` user whose credentials are stored on SSM

<p align="center">
  <img src="img/ecr-iam.png" alt="ecr-iam">
</p>
