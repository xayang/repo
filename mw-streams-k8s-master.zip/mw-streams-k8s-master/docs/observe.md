## Observe

HBC Observe strategy can be found [here.](https://github.com/saksdirect/hbc-common-k8s/blob/master/docs/observe.md#strategy)

`observe` namespace defines Monitoring, Alerting and Logging

```bash
# prometheus
kubectl port-forward service/prometheus-operator-prometheus 8001:9090 -n observe

# alertmanager
kubectl port-forward service/prometheus-operator-alertmanager 8002:9093 -n observe

# grafana
# username: admin
# password: prom-operator
kubectl port-forward service/prometheus-operator-grafana 8003:80 -n observe

# elasticsearch
kubectl port-forward service/elasticsearch-master 9200:9200 -n observe

# cerebro
kubectl port-forward service/cerebro 9000:80 -n observe

# kibana
kubectl port-forward service/kibana-kibana 9001:5601 -n observe
```

### Alerting

This uses a wrapper chart for [prometheus-operator](https://github.com/coreos/prometheus-operator/blob/master/Documentation/user-guides/alerting.md) (wrapping the one that's maintained by the community). Find the wrapper chart [here](https://github.com/saksdirect/mw-helm-charts). The idea is to have all the cluster wise prometheus alerts plus the Graphana Dashboards in one place, also so the configurations are a little bit more human friendly.<br/>
In this chart we only have value files for the alertmanager, Prometheus itself and Grafana Dashboards. In the case of the alertmanager values file there is one per environment so we can have different receiver configurations according to the environment.<br/>
In the following sections you will learn how to add new alerts and grafana dashboards but keep in mind that you can override any configuration from the prometheus operator chart.  

The official documentation for Prometheus Operator can be found [here.](https://github.com/coreos/prometheus-operator#prometheus-operator)

#### *How to configure an alert for an Application?*

1. Make sure the metric you want to alert on is being exported into the global Prometheus, you can check through the Prometheus UI.
2. Decide the severity of the alert. You will set the severity of alerts through the severity label. The alertmanager config routes alerts based on these labels. There are two severity levels:
    * `severity: critical` - (not configured yet) user's are being affected, send a pager duty alert.
    * `severity: warning` - user's are not being affected, send a slack message.
3. Create the PrometheusRule. Usually it should be placed in the Application's chart.
   Gotcha with Helm templating: PrometheusRules have their own templating engine for firing alerts. In the example below, the PrometheusRule summary uses double brackets for templating: `{{ $labels.namespace }}`. Helm also uses double brackets for templating and therefore PrometheusRule's brackets need to be escaped like so: `{{"{{"}}$labels.namespace{{"}}"}}`

    ```yaml
    apiVersion: monitoring.coreos.com/v1
    kind: PrometheusRule
    metadata:
      name: global-kube-alerts
      labels:
        app: prometheus-operator
        release: prometheus-operator
    spec:
      groups:
        - name: ./kubernete.rules
          rules:
            - alert: <ALERT NAME>
              expr: |
                <PROMETHEUS EXPRESSION>
              for: 30m
              labels:
                severity: warning
              annotations:
                summary: |-
                  In the namespace{{ "{{" }}$labels.namespace{{ "}}" }}- 
                  Container{{ "{{" }}$labels.container{{ "}}" }}within 
                  Pod {{ "{{" }}$labels.pod{{ "}}" }} is restarting{{ "{{" }}printf "%.2f" $value {{ "}}" }} / second
    ```

    *Notice this is merely an example, you may have to change the `annotations.summay` value based on the metric you want to alert on.*

4. Once the rule has been applied it can take up to a minute to be picked up by Prometheus. You can check in the Prometheus UI in the alerts tab if it is there. If it does not appear, a good place to start debugging is to see if the prometheus config reloader has been triggered.

`kubectl logs prometheus-prometheus-operator-prometheus-0 -c rules-configmap-reloader --namespace observe`

#### *How to configure cluster-wise alerts?*

You can also configure alerts for `kubernetes objects`, `kafka`, `argocd`, etc. In this case these kind of metrics do not belong to any specific Application so it is better if they are configured in a centrilized place.
Go to [prometheus-operator](https://github.com/saksdirect/mw-helm-charts) helm chart in the *mw-helm-charts* project in order to override the [prometheus-operator helm chart](https://github.com/coreos/prometheus-operator/blob/master/Documentation/user-guides/alerting.md). There find the file named *values-prometheus.yaml* where you can add new rules under *additionalPrometheusRules*.<br/>
You can also override other configurations such as *serviceMonitorNamespaceSelector*, *ruleNamespaceSelector*, *defaultRules* and in general any other default configuration from prometheus-operator helm chart.

Here's an example of an additional rule:

```yaml
 # (...)
     additionalPrometheusRules:
         - name: kubepodcrashloopingspikegroup
           groups:
             - name: KubePodCrashLoopingSpikeGroup
               rules:
                 - alert: KubePodCrashLoopingSpikeGroup
                   expr: rate(kube_pod_container_status_restarts_total{job="kube-state-metrics"}[15m]) > 0
                   for: 15m
                   labels:
                     severity: warning
                   annotations:
                     summary: In the namespace {{ $labels.namespace }} - Container {{ $labels.container }} within Pod {{ $labels.pod }} is restarting {{ printf "%.2f" $value }} / second
```

#### *Other AlertManager configurations*

##### Receivers

Currently *AlertManager* is configured to send alert notifications to Slack when an alert with warning severity is fired.
To update the Slack receiver configuration or add a new receiver go to [prometheus-operator](https://github.com/saksdirect/mw-helm-charts) and override the [prometheus-operator helm chart](https://github.com/coreos/prometheus-operator/blob/master/Documentation/user-guides/alerting.md) *alertmanager.config.receivers* parameter.

Here's an example:

```yaml
# (...)
  alertmanager:
      config:
        route:
          receiver: slack-notifications
          repeat_interval: 1h
          group_by: ['alertname']
          routes:
            - match_re:
                severity: warning
              receiver: slack-notifications
        receivers:
          - name: slack-notifications
            slack_configs:
              - channel: "<CHANNEL NAME>"
                api_url: "{{ .Values.slackUrl }}"
                title: |
                  [{{ .Values.environment }}] {{ .GroupLabels.alertname }} - {{ .Status | toUpper }}
                title_link: "http://$fqdn/"
                text: |
                  {{ range .Alerts }}{{ if .Annotations.summary }}Summary: {{ .Annotations.summary }}{{ end }}{{ if .Annotations.message }}Message: {{ .Annotations.message }}{{ end }}{{ end }}
                send_resolved: true
```
#### *Which are the Slack channels we are using?*
    - dev/dev-tmp clusters: #mw-streams-k8s-dev
    - prod cluster: #mw-streams-k8s-prod

#### *Which alerts do we have now?*
- ##### KubeDaemonSetRolloutStuck
  The rollout is stuck because new DaemonSet pods can't be scheduled on at least one node
- ##### KubePodNotReady 
  A pod has been in a non-ready state for longer than the expected time 
- ##### KubePodCrashLooping 
  A pod has been in CrashLoopBackOff state and it is restarting
- ##### Watchdog
  It is a simple Prometheus alerting rule that always triggers to ensure the availability of the monitoring infrastructure. This also ensures that communication between the Alertmanager and the notification provider is working.


### Grafana

To add a new Grafana Dashboard go to [prometheus-operator](https://github.com/saksdirect/mw-helm-charts) and place your dashboard JSON file in the folder named *files*. Please notice that the file name should end in *-dashboard*, otherwise it will not be picked up by the operator, hence it won't appear in Grafana.
We also have some Kafka dedicated Dashboards that you can find in [kafka-observe](https://github.com/saksdirect/mw-helm-charts/tree/master/kafka-observe/files)

#### Access to Grafana
There is a DNS entry for Grafana per environment. 
To access to Grafana you should log into AppGate first.

```bash
http://grafana.eks.<ENVIRONMENT>.streams.integration.awshbc.io
```
If you want to access to Grafana from dev-tmp-1 cluster, you should replace ENVIRONMENT value with the cluster name.

```bash
http://grafana.eks.dev-tmp-1.streams.integration.awshbc.io
```
Some urls:

[http://grafana.eks.dev.streams.integration.awshbc.io/](http://grafana.eks.dev.streams.integration.awshbc.io/)
[http://grafana.eks.prod.streams.integration.awshbc.io](http://grafana.eks.prod.streams.integration.awshbc.io/)

You can access to Grafana, also running a port-forward to prometheus-operator-grafana service, but this is not recommended.

```bash
kubectl port-forward service/prometheus-operator-grafana 8003:80 -n observe
```

For both scenarios credentials are:

```bash
# username: admin
# password: prom-operator
```


#### Useful Dashboards

   - [Kubernetes Kafka Topics](http://grafana.eks.dev.streams.integration.awshbc.io/d/kafka-topics/kubernetes-kafka-topics)
   - [Kubernetes / Stream Apps Resource](http://grafana.eks.dev.streams.integration.awshbc.io/d/W8xgybUZz/kubernetes-stream-apps-resource)
   - [Kubernetes Kafka](http://grafana.eks.dev.streams.integration.awshbc.io/d/kafka/kubernetes-kafka?orgId=1)

### Cerebro (ElasticSearch)

**Cerebro** is a web-based application for managing Elastisearch clusters.

There is a DNS entry for Cerebro per environment. 
To access to Cerebro you should log into AppGate first.

```bash
http://cerebro.eks.<ENVIRONMENT>.streams.integration.awshbc.io
```
If you want to access to Grafana from dev-tmp-1 cluster, you should replace ENVIRONMENT value with the cluster name.

```bash
http://cerebro.eks.dev-tmp-1.streams.integration.awshbc.io
```
Some urls:

[http://cerebro.eks.dev.streams.integration.awshbc.io/](http://cerebro.eks.dev.streams.integration.awshbc.io/)
[http://cerebro.eks.prod.streams.integration.awshbc.io](http://cerebro.eks.prod.streams.integration.awshbc.io/)

### Kibana

There is a DNS entry for Kibana per environment. 
To access to Kibana you should log into AppGate first.

```bash
http://kibana.eks.<ENVIRONMENT>.streams.integration.awshbc.io
```
If you want to access to Kibana from dev-tmp-1 cluster, you should replace ENVIRONMENT value with the cluster name.

```bash
http://kibana.eks.dev-tmp-1.streams.integration.awshbc.io
```
Some urls:

[http://kibana.eks.dev.streams.integration.awshbc.io/](http://kibana.eks.dev.streams.integration.awshbc.io/)
[http://kibana.eks.prod.streams.integration.awshbc.io](http://kibana.eks.prod.streams.integration.awshbc.io/)


### FAQ

#### *How to configure Kibana index to visualize logs?*

In order to visualize the logs collected by [Fluent Bit](https://fluentbit.io) on Kibana you must create manually the index

> Visualize > Create index pattern > Define index pattern > kubernetes_cluster-*

<p align="center">
  <img src="img/kibana-index-1.png" alt="kibana-index-1">
</p>

> Visualize > Create index pattern > Configure settings > @timestamp

<p align="center">
  <img src="img/kibana-index-2.png" alt="kibana-index-2">
</p>

#### *How to configure Prometheus to scrape metrics?*

> TODO

* [`ServiceMonitor`](https://github.com/coreos/prometheus-operator/blob/master/Documentation/user-guides/getting-started.md#related-resources)
* [`prometheus.io/scrape`](https://github.com/helm/charts/tree/master/stable/prometheus-operator#prometheusioscrape)
* [`PrometheusSpec`](https://github.com/coreos/prometheus-operator/blob/master/Documentation/api.md#prometheusspec)
* Chart [configuration](https://github.com/helm/charts/tree/master/stable/prometheus-operator#configuration)
* [Prometheus ServiceMonitor troubleshooting](https://support.coreos.com/hc/en-us/articles/360000155514-Prometheus-ServiceMonitor-troubleshooting)
