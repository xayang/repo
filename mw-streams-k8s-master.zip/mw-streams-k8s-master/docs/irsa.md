## IRSA - IAM Roles for Service Accounts

* [eksctl-irsa](https://eksctl.io/usage/iamserviceaccounts)
* [AWS Policy Generator](https://awspolicygen.s3.amazonaws.com/policygen.html)

With IAM Roles for Service Accounts you can associate an IAM role with a Kubernetes `ServiceAccount` to provide fine-grained permissions to resources in the cluster

### Policy setup

By default all policies are enforced when a cluster is created using the comand `make cluster-create`, no additional steps are required other then the following conventions

* policies name must start with `IntegrationStreams`

* policies must be declared in [`scripts/aws/iam-policies`](/scripts/aws/iam-policies) in JSON format

If you need to create/update a policy for a cluster that is already running, follow the steps below

```bash
# list custom policies
make iam-policy-list

# create/update policy
make iam-policy-setup policy=IntegrationStreamsXXX

# create/update all policies
make iam-policy-setup-all

# delete policy
make iam-policy-delete policy=IntegrationStreamsXXX
```

### Service Account setup

To bind a policy to a `ServiceAccount` you need to edit the [cluster configuration](/charts/clusters/templates/cluster.yaml)

```yaml
iam:
  # ...
  serviceAccounts:
  # ...
  - metadata:
      name: MY_SERVICE_ACCOUNT_NAME
      namespace: MY_NAMESPACE
    attachPolicyARNs:
    - "arn:aws:iam::280550751197:policy/IntegrationStreams_MY_POLICY_NAME"
```

and specify the `serviceAccountName` to a resource e.g. `Deployment`, `StatefulSet`, `CronJob` in your own chart

```yaml
# resource
---
apiVersion: apps/v1
kind: Deployment
# ...
spec:
  # ...
  template:
    # ...
    spec:
      # ...
      serviceAccountName: MY_SERVICE_ACCOUNT_NAME

# as best practice define a default service account
---
apiVersion: v1
kind: ServiceAccount
metadata:
  name: MY_SERVICE_ACCOUNT_NAME
```

During the bootstrap phase when the command `make bootstrap` is executed, `eksctl` using the `ClusterConfig` under the hood will create and add an annotation to the `ServiceAccount` i.e. `eks.amazonaws.com/role-arn`. EKS will then take care of injects in the `Pod` the credentials as environment variables

If you need to create/update a `ServiceAccount` for a cluster that is already running, follow the steps below

```bash
# list irsa
make cluster-list-irsa env=dev

# refresh all irsa
make cluster-refresh-irsa env=dev

# refresh an individual irsa, for instance "catalog-categories-jobs"
make cluster-refresh-individual-irsa env=dev service-account="catalog-categories-jobs" namespace="streams" policies="arn:aws:iam::280550751197:policy/IntegrationStreamsS3ReadOnlyAccess arn:aws:iam::280550751197:policy/IntegrationStreamsDynamoDBTableWriteAccess"
```

### FAQ

#### *How to make sure application has assumed the correct IAM role?*

When you initialize a new AWS service [client](https://docs.aws.amazon.com/AWSJavaSDK/latest/javadoc/com/amazonaws/client/builder/AwsClientBuilder.html) without supplying any arguments e.g.

```java
AmazonS3ClientBuilder.defaultClient()
AmazonDynamoDBClientBuilder.defaultClient()
AWSSecretsManagerClientBuilder.defaultClient()
```

the AWS SDK for Java attempts to find AWS credentials by using the default credential provider chain. The client will attempt the next credential provider if the current one fails. The last provider in the chain is EC2 instance delivered through the Amazon EC2 metadata service and in almost all cases this is not the role your application should assume since it's the least privileged. If you see error messages like the one below containing `NodeInstanceRole`, that's the role your application has assumed and it means all other credential providers on the chain have failed.

```bash
com.amazonaws.services.secretsmanager.model.AWSSecretsManagerException:
User: arn:aws:sts::280550751197:assumed-role/eksctl-mw-streams-k8s-dev-tmp-1-n-NodeInstanceRole-18X9IGOZ1W3J5/i-0e8fbd46e52e3baf3
  is not authorized to perform: secretsmanager:GetSecretValue
  on resource: arn:aws:secretsmanager:us-east-1:280550751197:secret:phoenix/staging/oms/stg3-UVZnoA
  (Service: AWSSecretsManager; Status Code: 400; Error Code: AccessDeniedException; Request ID: b9b6eb2d-9102-43df-9eb7-308fdb13d376)
```

We're using [fine-grained IAM roles for service accounts](https://aws.amazon.com/blogs/opensource/introducing-fine-grained-iam-roles-service-accounts/). The way it works is that two environment variables

* `AWS_ROLE_ARN`
* `AWS_WEB_IDENTITY_TOKEN_FILE`

are injected to the container and a volume named `aws-iam-token` is mounted which contains the service account token.

For this feature to work you need to make sure:

  - Your application is using `aws-java-sdk` *version 1.11.623 or later*. If you're not pulling that library directly, you can specify the version using sbt's `dependencyOverrides` setting.

    ```scala
    dependencyOverrides += "com.amazonaws" % "aws-java-sdk-core" % "1.11.661"
    ```

  - `aws-java-sdk-sts` is in your application's classpath
  
    ```scala
    libraryDependencies += "com.amazonaws" % "aws-java-sdk-sts" % "1.11.661"
    ```

  - The user used to execute your application in the container has read access to the token file at `AWS_WEB_IDENTITY_TOKEN_FILE`. Some tools used to generate Docker images like `sbt-native-packager` introduce a new daemon user and strip all other unix accounts (including root) from the image and that daemon user usually don't have enough privileges to read that file. One way of fixing it is to add the following to the spec of your resource:
    ```yaml
    ---
    apiVersion: apps/v1
    kind: Deployment
    metadata:
      # ...
    spec:
      # ...
      template:
        # ...
        spec:
          securityContext:
            fsGroup: 65534
    ```
    If in doubt where that belongs, it should be at the same level of `serviceAccountName`.
