## External DNS
[Helm Chart and Configuration](https://github.com/helm/charts/tree/master/stable/external-dns)

External-DNS synchronizes Kuberenetes Ingress and Service objects with external DNS services.  In our case, external-dns handles mapping Ingress and Service objects to AWS load balancers and handles mapping the load balancers to a Route 53 alias.

- [External DNS](#external-dns)
  - [Cluster Integration](#cluster-integration)
  - [Service and Ingress Setup](#service-and-ingress-setup)
  - [Example Configuration of ArgoCD UI](#example-configuration-of-argocd-ui)
  - [Route53 Actions Taken By External DNS](#route53-actions-taken-by-external-dns)


### Cluster Integration
External-dns is configured as an Argo application during bootstrap.  The Argo application file can be found [here](../applications/templates/kube-aws/external-dns.yaml).  The add-on is fixed to use the Route 53 zone `integration.awshbc.io` which is a namespace dedicated to the hbc-integration account.  Subdomains are not utilized. Any environment distinctions should be encapsulated in the hostname using the naming convention:  **[service].[namespace].[instance].[cluster].[domain]**.    Example:  `argocd.eks.dev.streams.integration.awshbc.io` for a development environment and `argocd.eks.prod.streams.integration.awshbc.io` for the production version of the argocd application.  The `applications` application receives the following paramters to use in endpoint names:

```
instance = Corresponds to the "env" value used to build and bootstrap the cluster.

cluster = EKS cluster type within the AWS account.  Currently either "loyalty", or "streams".

domain = Route 53 hosted zone where the dns record will live
```
The `service` parameter should be the name of the application service (e.g.: grafana, argo, kibana...etc).   The `namespace` parameter is a logical identifier for a related group of services (e.g. eks, observe...etc)

A note on Endpoint Exposure:

Every VPC used for the mw streams project is accessible through AppGate to the development team.  No endpoints are required to be exposed to the public internet. You must use internal load balancers when exposing an endpoint and it will be accessible anywhere through AppGate and directly from the HBC datacenters.


### Service and Ingress Setup
External-dns handles detections of hosts for Ingress and Service objects differently. At a minimum the following must be done for each object:

1) Ingress - A DNS record is created based on the **host** attribute on the ingress object.

Ex:
```
apiVersion: extensions/v1beta1
kind: Ingress
metadata:
  name: nginx
spec:
  rules:
  - host: myhost-name.integration.hbc.com
    http:
      paths:
      - backend:
          serviceName: nginx
          servicePort: 80
```

2) Service - A DNS record is created based on the **external-dns.alpha.kubernetes.io/hostname** annotation on the service object.  **OF NOTE**:  Only Services of `spec.type` *LoadBalancer* are supported.

Ex:
```
apiVersion: v1
kind: Service
metadata:
  name: some-name
  annotations:
    external-dns.alpha.kubernetes.io/hostname: "myhost-name.integration.hbc.com"
spec:
  ports:
  - name: http
    port: 80
    protocol: TCP
    targetPort: 8080
  selector:
    app.kubernetes.io/name: some-deployment-selector
  type: LoadBalancer
```

There are additional load balancer configurations you can make through annotations placed on the Ingress/Service manifest.  
Please see the following for details:
https://kubernetes.io/docs/concepts/cluster-administration/cloud-providers/#aws


### Example Configuration of ArgoCD UI
An example implementation of the External DNS annotations can be found in the file [applications/templates/argocd/service.yaml](../applications/templates/argocd/service.yaml)

This defines a Service object pointing to the argoc-cd server Pods.


### Route53 Actions Taken By External DNS
External DNS is not responsible for creating and configuring load balancers that route to a Service.  These are managed by Kuberentes AWS external cloud provider extension defined at https://kubernetes.io/docs/concepts/cluster-administration/cloud-providers/#aws.

External DNS creates a CNAME alias record in the configured Route53 zone pointing to the ELB address.  Additionally, External DNS creates a corresponding TXT record with the sname name as the CNAME record.  The TXT record  identifies the  Cluster and Service that owns the CNAME record.  This is used for updates and deletion of records.

### List of Applications Routes

Base URL: ```http://[APPLICATION].eks.[ENVIRONMENT].streams.integration.awshbc.io```

- [ArgoCD](http://argocd.eks.prod.streams.integration.awshbc.io)
- [Cerebro](http://cerebro.eks.prod.streams.integration.awshbc.io)
- [Grafana](http://grafana.eks.prod.streams.integration.awshbc.io)
- [Kibana](http://kibana.eks.prod.streams.integration.awshbc.io)
- [Prometheus](http://prometheus.eks.prod.streams.integration.awshbc.io)
- [Schema Registry UI](http://schema-registry-ui.eks.prod.streams.integration.awshbc.io)
- [Kafka Connect UI](http://kafka-connect-ui.eks.prod.streams.integration.awshbc.io)
- [Kafka Topic UI](http://kafka-topic-ui.eks.prod.streams.integration.awshbc.io)

Additionally, we can access development routes just changing the environment in the Base URL. e.g: ```http://argocd.eks.dev.streams.integration.awshbc.io``` 
