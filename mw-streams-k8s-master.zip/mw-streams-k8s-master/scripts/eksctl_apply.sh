#!/bin/bash

# unofficial bash strict mode
set -euo pipefail

# run from any directory (no symlink allowed)
CURRENT_PATH=$(cd "$(dirname "${BASH_SOURCE[0]}")"; pwd -P)
cd ${CURRENT_PATH}

##############################

PARAM_ACTION=${1:?"Missing ACTION"}
# e.g. dev|dev-tmp-N|prod
PARAM_ENVIRONMENT=${2:?"Missing ENVIRONMENT"}

ROOT_PATH="${CURRENT_PATH}/.."
AWS_PROFILE="hbc-integration"
CLUSTER_PREFIX="mw-streams-k8s"
CLUSTER_NAME="${CLUSTER_PREFIX}-${PARAM_ENVIRONMENT}"

##############################


function tag_eks_cluster {
  local CLUSTER_ARN=$(aws eks describe-cluster --name ${CLUSTER_NAME} --query cluster.arn --output text --profile ${AWS_PROFILE})

  # HBC standard AWS resource tags are defined in the following document
  # https://docs.google.com/spreadsheets/d/1nCMAyXE7Yictt69-_Yuej7Ojbmp4CMjfJgF8Yz1BDqM/edit#gid=0
  aws eks tag-resource --resource-arn $CLUSTER_ARN --tags \
  environment=${PARAM_ENVIRONMENT},banner=ent,compliance=Non-PCI,owner=phoenix@hbc.com,application=sfcc,exposure=private,projectname=SFCC,projectcode=CR194049 \
  --profile ${AWS_PROFILE}
}

function generate_cluster_config {
  local CLUSTER_CHART_PATH="${ROOT_PATH}/charts/clusters"
  local CONFIG_BASE_PATH="${ROOT_PATH}/scripts/clusters"
  local CONFIG_PATH="${CONFIG_BASE_PATH}/${CLUSTER_NAME}.yaml"

  rm -fr ${CONFIG_BASE_PATH}
  mkdir -p ${CONFIG_BASE_PATH}

  echo -e "### AUTO-GENERATED - DO NOT EDIT ###\n" >> ${CONFIG_PATH}

  helm template \
    --set environment=${PARAM_ENVIRONMENT} \
    --values="${CLUSTER_CHART_PATH}/values.yaml" ${CLUSTER_CHART_PATH} >> ${CONFIG_PATH}

  echo ${CONFIG_PATH}
}

function delete_namespaces {
  # avoids autosync
  kubectl delete namespace argocd

  # delete left namespaces except k8s system ones
  local NAMESPACES=$(kubectl get namespaces -o json | jq  '.items[].metadata | select(.name|test("(kube-*)|(default|argocd)") | not) | .name' --raw-output)
  for namespace in $NAMESPACES
  do
    kubectl delete namespace $namespace
  done
}

##############################

echo "[+] eksctl_apply"

echo "[*] ACTION=${PARAM_ACTION}"
echo "[*] CLUSTER_NAME=${CLUSTER_NAME}"

case ${PARAM_ACTION} in
  "create")
    # TODO verify serviceAccount is created or update with --override-existing-iamserviceaccount
    eksctl create cluster \
      --profile ${AWS_PROFILE} \
      --config-file="$(generate_cluster_config)"
    # add required tags
    tag_eks_cluster
    # make cluster API endpoint private
    aws --profile ${AWS_PROFILE}  eks update-cluster-config --region us-east-1 \
    --resources-vpc-config endpointPublicAccess=false,endpointPrivateAccess=true --name ${CLUSTER_NAME}
  ;;
  "config")
    eksctl utils write-kubeconfig \
      --cluster ${CLUSTER_NAME} \
      --profile ${AWS_PROFILE} \
      --kubeconfig ~/.kube/config-eks-${AWS_PROFILE}.yaml
  ;;
  "list")
    eksctl get cluster \
      --profile ${AWS_PROFILE}
  ;;
  "list-irsa")
    eksctl get iamserviceaccount \
      --profile ${AWS_PROFILE} \
      --config-file="$(generate_cluster_config)"
    
    kubectl get serviceaccounts --all-namespaces
  ;;
  "refresh-irsa")
    echo "[*] delete iamserviceaccount resources"
    eksctl delete iamserviceaccount \
      --profile ${AWS_PROFILE} \
      --config-file="$(generate_cluster_config)" \
      --approve
    
    echo "[*] sleeping 10 seconds..."
    sleep 10

    echo "[*] create iamserviceaccount resources"
    eksctl create iamserviceaccount \
      --profile ${AWS_PROFILE} \
      --config-file="$(generate_cluster_config)" \
      --override-existing-serviceaccounts \
      --approve
  ;;
  "refresh-individual-irsa")
    PARAM_SERVICE_ACCOUNT=${3:?"Missing SERVICE ACCOUNT"}
    PARAM_NAMESPACE=${4:?"Missing NAMESPACE"}
    PARAM_POLICIES=${5:?"Missing POLICIES"}

    IFS=' '
    ATTACHED_POLICIES=""
    read -ra POLICIES <<< "${PARAM_POLICIES}"
    for i in "${POLICIES[@]}"; do
      ATTACHED_POLICIES+="--attach-policy-arn=\"$i\" "
    done

    echo "[*] delete iamserviceaccount resources"
    eksctl delete iamserviceaccount --profile="${AWS_PROFILE}" --name="${PARAM_SERVICE_ACCOUNT}" --namespace="${PARAM_NAMESPACE}" --cluster="${CLUSTER_NAME}"

    echo "[*] sleeping 10 seconds..."
    sleep 10

    eksctl create iamserviceaccount --profile="${AWS_PROFILE}" \
      --name="${PARAM_SERVICE_ACCOUNT}" \
      --override-existing-serviceaccounts \
      --namespace="${PARAM_NAMESPACE}" \
      --cluster="${CLUSTER_NAME}" \
      ${ATTACHED_POLICIES} \
      --approve
   ;;
  "delete")
    echo "[*] delete namespaces"
    delete_namespaces

    echo "[*] sleeping 10 minutes..."
    sleep 600

    echo "[*] delete cluster"
    eksctl delete cluster \
      --profile ${AWS_PROFILE} \
      --config-file="$(generate_cluster_config)" \
      --wait
  ;;
  *)
    echo "ERROR: unknown command"
    exit 1
  ;;
esac

echo "[-] eksctl_apply"
