#!/bin/bash

# unofficial bash strict mode
set -euo pipefail

# run from any directory (no symlink allowed)
CURRENT_PATH=$(cd "$(dirname "${BASH_SOURCE[0]}")"; pwd -P)
cd ${CURRENT_PATH}

##############################

function get_cluster_environment {
  local CLUSTER_SUFFIX=$1
  local ENVIRONMENT=$(echo $CLUSTER_SUFFIX | sed -E "s/^(dev|prod).*/\1/")
  
  echo $ENVIRONMENT
}

function get_secret_string {
  local SECRET_ID=$1
  local JQ_FILTER=$2

  aws secretsmanager get-secret-value \
    --region "us-east-1" \
    --profile "hbc-integration" \
    --secret-id "$SECRET_ID" \
    --version-stage AWSCURRENT | jq -r ".SecretString $JQ_FILTER"
}

function get_private_deploy_key {
  local REPOSITORY_NAME=$1
  local SECRET_ID="eks/argocd/deploy-key/github.com/saksdirect/$REPOSITORY_NAME"

  get_secret_string $SECRET_ID '| fromjson | .sshPrivateKey'
}

##############################

PARAM_CLUSTER_SUFFIX=${1:?"Missing CLUSTER_SUFFIX"}
PARAM_VERSION=${2:-"HEAD"}

NAMESPACE="argocd"
CHART_NAME="argocd"
CLUSTER_ENVIRONMENT=$(get_cluster_environment $PARAM_CLUSTER_SUFFIX)
SECRET_MW_STREAMS_K8S=$(get_private_deploy_key mw-streams-k8s)
SECRET_MW_HELM_CHARTS=$(get_private_deploy_key mw-helm-charts)

ROOT_PATH="${CURRENT_PATH}/.."
ARGOCD_CONFIG_PATH="${ROOT_PATH}/charts/argocd-config/"
BOOTSTRAP_PATH="${ROOT_PATH}/charts/bootstrap/"

echo "[+] bootstrap"
echo "[*] CLUSTER_ENVIRONMENT=${CLUSTER_ENVIRONMENT}"
echo "[*] CLUSTER_INSTANCE=${PARAM_CLUSTER_SUFFIX}"
echo "[*] VERSION=${PARAM_VERSION}"

cd ${ARGOCD_CONFIG_PATH}

# add helm repository
helm repo add argo https://argoproj.github.io/argo-helm

# download chart locally
helm dependency update

cd ${BOOTSTRAP_PATH}

helm dependency update

# apply bootstrap chart
# --namespace overrides default argocd .Release.Namespace in sub-chart to fix error:
# Failed to sync cluster XXX is forbidden: User XXX cannot XXX at the cluster scope
helm template \
  --namespace ${NAMESPACE} \
  --name ${CHART_NAME} \
  --set common.environment=${CLUSTER_ENVIRONMENT} \
  --set common.instance=${PARAM_CLUSTER_SUFFIX} \
  --set repository.targetRevision=${PARAM_VERSION} \
  --set sshPrivateKey.mwStreamsK8s="${SECRET_MW_STREAMS_K8S}" \
  --set sshPrivateKey.mwHelmCharts="${SECRET_MW_HELM_CHARTS}" \
  --values "values.yaml" . | kubectl apply -n ${NAMESPACE} -f -

echo "[-] bootstrap"
