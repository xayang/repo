#!/usr/bin/env bash
set -euxo pipefail
#WIP TODO SFCC1-858
echo "[+] sync_argocd"
kubectl port-forward svc/argocd-server -n argocd 8080:443 &
sleep 2
argocd login localhost:8080 --username admin --password argocd --insecure
sleep 2
argocd app sync --force applications
sleep 10
argocd app sync --force aws-secret-operator
sleep 10
argocd app sync --force aws-secrets
sleep 10
argocd app sync --force argocd-config

pkill kubectl
echo "[-] sync_argocd"
