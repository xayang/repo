#!/bin/bash

# unofficial bash strict mode
set -euo pipefail

# run from any directory (no symlink allowed)
CURRENT_PATH=$(cd "$(dirname "${BASH_SOURCE[0]}")"; pwd -P)
cd ${CURRENT_PATH}

##############################

PARAM_ACTION=${1:?"Missing ACTION"}
# e.g. dev|dev-tmp-N|prod
PARAM_ENVIRONMENT=${2:?"Missing ENVIRONMENT"}

ROOT_PATH="${CURRENT_PATH}/.."
AWS_PROFILE="hbc-integration"
CLUSTER_PREFIX="mw-streams-k8s"
CLUSTER_NAME="${CLUSTER_PREFIX}-${PARAM_ENVIRONMENT}"
CLUSTER_TAG_NAME="kubernetes.io/cluster/$CLUSTER_NAME"

##############################

function list_ebs_volumes {
  aws --profile $AWS_PROFILE ec2 describe-volumes --filters "Name=tag:$CLUSTER_TAG_NAME,Values=*" --query 'Volumes[*].[VolumeId,State]' --output text
}

function delete_ebs_volumes {
  for volumeId in $(aws --profile $AWS_PROFILE ec2 describe-volumes --filters "Name=tag:$CLUSTER_TAG_NAME,Values=*" "Name=status,Values=available" --query 'Volumes[*].VolumeId' --output text)
  do 
    echo "deleting volumeId: $volumeId"
    aws ec2 delete-volume --volume-id $volumeId
  done
}

##############################

echo "[+] aws_volumes_apply"

echo "[*] ACTION=${PARAM_ACTION}"
echo "[*] CLUSTER_NAME=${CLUSTER_NAME}"

case ${PARAM_ACTION} in
  "list")
    list_ebs_volumes
  ;;
  "delete")
    delete_ebs_volumes
  ;;
  *)
    echo "ERROR: unknown ACTION.  Valid ACTIONs: list, delete"
    exit 1
  ;;
esac

echo "[-] aws_volumes_apply"
