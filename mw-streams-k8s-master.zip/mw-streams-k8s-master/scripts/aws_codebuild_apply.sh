#!/bin/bash

set -euo pipefail

CURRENT_PATH=$(cd "$(dirname "${BASH_SOURCE[0]}")"; pwd -P)
cd ${CURRENT_PATH}

##############################

PARAM_ACTION=${1:?"Missing ACTION"}
# example xxx-cluster
PARAM_PROJECT=${2:?"Missing PROJECT"}

ROOT_PATH="${CURRENT_PATH}/.."
TEMPLATE_PATH="${ROOT_PATH}/scripts/aws/cloud-formation"

AWS_REGION="us-east-1"
AWS_PROFILE="hbc-integration"
PROJECT_PREFIX="codebuild-mw-streams-k8s"
STACK_NAME="$PROJECT_PREFIX-$PARAM_PROJECT-stack"
PROJECT_NAME="$PROJECT_PREFIX-$PARAM_PROJECT-project"

##############################

function verify_project_buildspec {
  local PROJECT_PATH="${TEMPLATE_PATH}/${PARAM_PROJECT}-buildspec.yaml"

  if [[ ! -f ${PROJECT_PATH} ]]; then
    echo "[-] ERROR: invalid project builspec: ${PROJECT_PATH}"
    exit 1
  fi
}

function get_current_branch_name {
  local BRANCH_NAME=$(git rev-parse --abbrev-ref HEAD)
  echo $BRANCH_NAME
}

##############################

echo "[+] aws_codebuild_apply"
echo "[*] ACTION=${PARAM_ACTION}"
echo "[*] STACK_NAME=${STACK_NAME}"
echo "[*] PROJECT_NAME=${PROJECT_NAME}"

# TODO use jq to write --parameters and --environment-variables-override

case ${PARAM_ACTION} in
  "list")
    aws codebuild list-projects \
      --profile ${AWS_PROFILE} \
      --sort-by NAME \
      --sort-order ASCENDING | jq '.projects[]' | grep -i ${PROJECT_PREFIX}
  ;;
  "create")
    verify_project_buildspec

    aws cloudformation create-stack \
      --profile ${AWS_PROFILE} \
      --stack-name ${STACK_NAME} \
      --template-body "file://${TEMPLATE_PATH}/codebuild.template" \
      --capabilities CAPABILITY_NAMED_IAM \
      --parameters \
      '[{"ParameterKey":"projectPrefix", "ParameterValue": "'$PROJECT_PREFIX'"}, {"ParameterKey":"projectName", "ParameterValue":"'$PARAM_PROJECT'"}]'
  ;;
  "delete")
    verify_project_buildspec

    aws cloudformation delete-stack \
      --profile ${AWS_PROFILE} \
      --stack-name ${STACK_NAME}
  ;;
  "start")
    verify_project_buildspec

    PARAM_ENVIRONMENT=${3:?"Missing ENVIRONMENT"}
    PARAM_VERSION=${4:-"HEAD"}
    SOURCE_VERSION=$(get_current_branch_name)

    aws codebuild start-build \
      --profile ${AWS_PROFILE} \
      --project-name ${PROJECT_NAME} \
      --source-version ${SOURCE_VERSION} \
      --environment-variables-override \
      '[{"name":"ENVIRONMENT", "value":"'$PARAM_ENVIRONMENT'", "type":"PLAINTEXT"}, {"name":"VERSION", "value":"'$PARAM_VERSION'", "type":"PLAINTEXT"}]'
  ;;
  *)
    echo "ERROR: unknown command"
    exit 1
  ;;
esac

echo "[-] aws_codebuild_apply"
