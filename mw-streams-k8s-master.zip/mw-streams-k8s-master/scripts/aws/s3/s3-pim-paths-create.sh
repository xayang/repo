#############################
##Create S3 bucket and apply tags
aws s3api create-bucket --bucket $bucket --region us-east-1
aws s3api put-bucket-tagging --bucket $bucket --tagging "TagSet=[{Key=banner,Value=ent}, {Key=compliance,Value=Non-PCI}, {Key=owner,Value=phoenix@hbc.com}, {Key=application,Value=sfcc}, {Key=exposure,Value=private}, {Key=projectname,Value=SFCC}, {Key=projectcode,Value=CR194049}, {Key=environment,Value=${env}}]"
echo making $bucket public-read
aws s3api put-object --bucket $bucket --key bay/placeholder.txt
aws s3api put-object --bucket $bucket --key bay/Workflow/placeholder.txt
aws s3api put-object --bucket $bucket --key bay/Workflow/Products/placeholder.txt
aws s3api put-object --bucket $bucket --key bay/Workflow/SKU/placeholder.txt
aws s3api put-object --bucket $bucket --key bay/categories/placeholder.txt
aws s3api put-object --bucket $bucket --key bay/products/placeholder.txt
aws s3api put-object --bucket $bucket --key bay/skus/placeholder.txt
aws s3api put-object --bucket $bucket --key bay/test-lambda/placeholder.txt
aws s3api put-object --bucket $bucket --key o5a/placeholder.txt
aws s3api put-object --bucket $bucket --key o5a/Workflow/placeholder.txt
aws s3api put-object --bucket $bucket --key o5a/Workflow/Products/placeholder.txt
aws s3api put-object --bucket $bucket --key o5a/Workflow/SKU/placeholder.txt
aws s3api put-object --bucket $bucket --key o5a/categories/placeholder.txt
aws s3api put-object --bucket $bucket --key o5a/products/placeholder.txt
aws s3api put-object --bucket $bucket --key o5a/skus/placeholder.txt
