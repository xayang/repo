#!/bin/bash

# Tags are defined in following document:
# https://docs.google.com/spreadsheets/d/1nCMAyXE7Yictt69-_Yuej7Ojbmp4CMjfJgF8Yz1BDqM/edit#gid=0
# These are fixed values for all tags

BASE_TAGS='[{"Key": "banner", "Value": "ent"},{"Key": "compliance", "Value": "Non-PCI"},{"Key": "owner", "Value": "phoenix@hbc.com"},{"Key": "application", "Value": "sfcc"},{"Key": "exposure", "Value": "private"},{"Key": "projectname", "Value": "SFCC"},{"Key": "projectcode", "Value": "CR194049"}'

declare -a DEV_SECRETS=(phoenix/development/cms/bay 
phoenix/development/cms/saks
eks/okta/oidc/mw-streams-k8s/dev/clientsecret
eks/okta/oidc/integration-streams-k8s/dev/clientsecret
eks/okta/oidc/mw-streams-k8s/dev/clientid
phoenix/development/scene7/manifest
phoenix/development/rfs/bay
phoenix/development/rfs/o5a)

declare -a INTEGRATION_SECRETS=(phoenix/integration/cms/bay
eks/argocd/deploy-key/github.com/saksdirect/integration-streams-k8s
eks/argocd/deploy-key/github.com/saksdirect/integration-helm-charts
eks/okta/oidc/integration-streams-k8s/dev/clientsecret
eks/okta/oidc/integration-streams-k8s/prod/clientsecret
phoenix/integration/cms/o5a
phoenix/integration/cms/s5a)

declare -a STAGING_SECRETS=(phoenix/staging/oms/stg2
phoenix/staging/oms/stg3
phoenix/staging/stores/stg3
phoenix/staging/stores/stg2
phoenix/staging/rfs
phoenix/staging/oms/stg1
phoenix/staging/stores/stg1)

declare -a PRODUCTION_SECRETS=(phoenix/production/cms/bay
phoenix/production/cms/saks
phoenix/production/scene7/manifest
phoenix/production/cms/bay
phoenix/production/cms/o5a
phoenix/production/cms/s5a
phoenix/production/rfs
phoenix/production/rfs/bay
phoenix/production/rfs/o5a
phoenix/production/stores/prd2
phoenix/production/stores/prd3
phoenix/production/oms/prd2
phoenix/production/oms/prd3
phoenix/travisci/iam-credentials
phoenix/service-account/phoenix-user
phoenix/codebuild/iam-credentials
eks/argocd/deploy-key/github.com/saksdirect/mw-inventory
eks/argocd/deploy-key/github.com/saksdirect/mw-s3-sink
eks/argocd/deploy-key/github.com/saksdirect/mw-streams-k8s
eks/argocd/deploy-key/github.com/saksdirect/mw-helm-charts
eks/argocd/deploy-key/github.com/saksdirect/mw-stores
eks/argocd/deploy-key/github.com/saksdirect/mw-catalog
eks/argocd/deploy-key/github.com/saksdirect/integration-streams-k8s
eks/argocd/deploy-key/github.com/saksdirect/integration-helm-charts
eks/argocd/deploy-key/github.com/saksdirect/mw-promotions
eks/argocd/deploy-key/github.com/saksdirect/mw-s3-source
eks/argocd/deploy-key/github.com/saksdirect/mw-prices
eks/argocd/deploy-key/github.com/saksdirect/mw-sink-to-ddw)


function tag_secrets {
local TAGS=$1
shift
local SECRETS=("$@") 

for secret in ${SECRETS[@]}
do
  echo "Tagging secret: $secret"
  aws secretsmanager tag-resource --secret-id $secret --tags "$TAGS"
done
}

DEV_TAGS="$BASE_TAGS,{\"Key\": \"environment\", \"Value\": \"development\"}]"
tag_secrets "${DEV_TAGS}" "${DEV_SECRETS[@]}"

INTEGRATION_TAGS="$BASE_TAGS,{\"Key\": \"environment\", \"Value\": \"qa\"}]"
tag_secrets "$INTEGRATION_TAGS" "${INTEGRATION_SECRETS[@]}"

STAGING_TAGS="$BASE_TAGS,{\"Key\": \"environment\", \"Value\": \"stage\"}]"
tag_secrets "$STAGING_TAGS" "${STAGING_SECRETS[@]}"

PRODUCTION_TAGS="$BASE_TAGS,{\"Key\": \"environment\", \"Value\": \"production\"}]"
tag_secrets "$PRODUCTION_TAGS" "${PRODUCTION_SECRETS[@]}"
