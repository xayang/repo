#!/bin/bash

set -euo pipefail

CURRENT_PATH=$(cd "$(dirname "${BASH_SOURCE[0]}")"; pwd -P)
cd ${CURRENT_PATH}

##############################

PARAM_ACTION=${1:?"Missing ACTION"}
# example "vX.Y.Z"
PARAM_VERSION=${2:?"Missing VERSION"}
# remove prefix "v"
VERSION=${PARAM_VERSION#"v"}

AWS_ACCOUNT_ID="280550751197"
AWS_REGION="us-east-1"
AWS_PROFILE="hbc-integration"
DOCKER_REGISTRY="${AWS_ACCOUNT_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com"
REPOSITORY_NAME="${AWS_PROFILE}/mw-streams-k8s"
ECR_REPOSITORY="${DOCKER_REGISTRY}/${REPOSITORY_NAME}"

ROOT_PATH="${CURRENT_PATH}/.."

##############################

echo "[+] docker_apply"

echo "[*] ACTION=${PARAM_ACTION}"
echo "[*] VERSION=${VERSION}"
echo "[*] ECR_REPOSITORY=${ECR_REPOSITORY}"

case ${PARAM_ACTION} in
  "build")
    # change directory to avoid COPY failed: Forbidden path outside the build context
    cd ${ROOT_PATH}
    docker build -t ${REPOSITORY_NAME} -f "${ROOT_PATH}/scripts/docker/Dockerfile" .
  ;;
  "package")
    docker tag ${REPOSITORY_NAME} "${ECR_REPOSITORY}:${VERSION}"
    docker tag ${REPOSITORY_NAME} "${ECR_REPOSITORY}:latest"
  ;;
  "publish")
    docker push "${ECR_REPOSITORY}:${VERSION}"
    docker push "${ECR_REPOSITORY}:latest"
  ;;
  *)
    echo "ERROR: unknown command"
    exit 1
  ;;
esac

echo "[-] docker_apply"
