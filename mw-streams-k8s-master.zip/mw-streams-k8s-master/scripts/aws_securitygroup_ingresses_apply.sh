#!/bin/bash

# unofficial bash strict mode
set -euo pipefail

# run from any directory (no symlink allowed)
CURRENT_PATH=$(cd "$(dirname "${BASH_SOURCE[0]}")"; pwd -P)
cd ${CURRENT_PATH}

##############################

PARAM_ACTION=${1:?"Missing ACTION"}
# e.g. dev|dev-tmp-N|prod
PARAM_ENVIRONMENT=${2:?"Missing ENVIRONMENT"}

ROOT_PATH="${CURRENT_PATH}/.."
AWS_PROFILE="hbc-integration"
CLUSTER_PREFIX="mw-streams-k8s"
CLUSTER_NAME="${CLUSTER_PREFIX}-${PARAM_ENVIRONMENT}"
APPGATE_BASTION_VPC_CIDR="10.136.16.0/24"
NAGIOS_HOST_CIDR="92.242.140.21/32"

##############################

function get_controlplain_securitygroup_id {
  aws --profile $AWS_PROFILE eks describe-cluster --name $CLUSTER_NAME --query cluster.resourcesVpcConfig.clusterSecurityGroupId --output text
}

function get_node_securitygroup_ids {
  aws --profile $AWS_PROFILE ec2 describe-security-groups --filters "Name=tag:alpha.eksctl.io/cluster-name,Values=$CLUSTER_NAME" "Name=tag:alpha.eksctl.io/nodegroup-name,Values=*" --query "SecurityGroups[*].GroupId" --output text
}

function delete_appgate_accessible_ingresses {
  # remove ingress on port 443 to api endpoint 
  local CONTROL_PLAIN_SECURITYGROUP_ID=$(get_controlplain_securitygroup_id)
  aws --profile $AWS_PROFILE ec2 revoke-security-group-ingress --group-id $CONTROL_PLAIN_SECURITYGROUP_ID --protocol tcp --cidr $APPGATE_BASTION_VPC_CIDR --port 443
  
  # remove ingress on load balancer exposed ports to services
  local NODE_SECURITYGROUP_IDS=$(get_node_securitygroup_ids)
  for group_id in $(echo $NODE_SECURITYGROUP_IDS)
  do
    aws --profile $AWS_PROFILE ec2 revoke-security-group-ingress --group-id $group_id --protocol tcp --cidr $APPGATE_BASTION_VPC_CIDR --port 80
    aws --profile $AWS_PROFILE ec2 revoke-security-group-ingress --group-id $group_id --protocol tcp --cidr $APPGATE_BASTION_VPC_CIDR --port 443
    aws --profile $AWS_PROFILE ec2 revoke-security-group-ingress --group-id $group_id --protocol tcp --cidr $NAGIOS_HOST_CIDR --port 80
    aws --profile $AWS_PROFILE ec2 revoke-security-group-ingress --group-id $group_id --protocol tcp --cidr $NAGIOS_HOST_CIDR --port 443
  done
}


function create_appgate_accessible_ingresses {
  # open port 443 to api endpoint 
  local CONTROL_PLAIN_SECURITYGROUP_ID=$(get_controlplain_securitygroup_id)
  aws --profile $AWS_PROFILE ec2 authorize-security-group-ingress --group-id $CONTROL_PLAIN_SECURITYGROUP_ID --protocol tcp --cidr $APPGATE_BASTION_VPC_CIDR --port 443
  
  # open ingress on load balancer exposed ports to services
  local NODE_SECURITYGROUP_IDS=$(get_node_securitygroup_ids)
  for group_id in $(echo $NODE_SECURITYGROUP_IDS)
  do
    aws --profile $AWS_PROFILE ec2 authorize-security-group-ingress --group-id $group_id --protocol tcp --cidr $APPGATE_BASTION_VPC_CIDR --port 80
    aws --profile $AWS_PROFILE ec2 authorize-security-group-ingress --group-id $group_id --protocol tcp --cidr $APPGATE_BASTION_VPC_CIDR --port 443
    aws --profile $AWS_PROFILE ec2 authorize-security-group-ingress --group-id $group_id --protocol tcp --cidr $NAGIOS_HOST_CIDR --port 80
    aws --profile $AWS_PROFILE ec2 authorize-security-group-ingress --group-id $group_id --protocol tcp --cidr $NAGIOS_HOST_CIDR --port 443
  done
}

function list_appgate_accessible_ingresses {
  local CONTROL_PLAIN_SECURITYGROUP_ID=$(get_controlplain_securitygroup_id)
  local NODE_SECURITYGROUP_IDS=$(get_node_securitygroup_ids)
  echo "[*] INGRESS RULES FOR CONTROL PLANE"
  aws --profile $AWS_PROFILE ec2 describe-security-groups --group-id $CONTROL_PLAIN_SECURITYGROUP_ID

  echo "[*] INGRESS RULES FOR NODES"
  for group_id in $(echo $NODE_SECURITYGROUP_IDS)
  do
    aws --profile $AWS_PROFILE ec2 describe-security-groups --group-id $group_id
  done
}

##############################

echo "[+] aws_securitygroup_ingresses_apply"

echo "[*] ACTION=${PARAM_ACTION}"
echo "[*] CLUSTER_NAME=${CLUSTER_NAME}"

case ${PARAM_ACTION} in
  "create")
    create_appgate_accessible_ingresses
  ;;
  "list")
    list_appgate_accessible_ingresses
  ;;
  "delete")
    delete_appgate_accessible_ingresses
  ;;
  *)
    echo "ERROR: unknown ACTION.  Valid ACTIONs: create, list, delete"
    exit 1
  ;;
esac

echo "[-] aws_securitygroup_ingresses_apply"
