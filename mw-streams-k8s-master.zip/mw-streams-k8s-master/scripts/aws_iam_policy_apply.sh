#!/bin/bash

set -euo pipefail

CURRENT_PATH=$(cd "$(dirname "${BASH_SOURCE[0]}")"; pwd -P)
cd ${CURRENT_PATH}

##############################

PARAM_ACTION=${1:?"Missing ACTION"}

AWS_PROFILE="hbc-integration"
POLICY_PREFIX="IntegrationStreams"
POLICY_ARN_BASE="arn:aws:iam::280550751197:policy"
POLICY_PATH="${CURRENT_PATH}/aws/iam-policies"

##############################

function policy_exists {
  local POLICY_NAME=$1
  local POLICY_ARN="${POLICY_ARN_BASE}/${POLICY_NAME}"

  # if doesn't exist an error is returned instead of a valid JSON
  aws iam get-policy \
    --profile ${AWS_PROFILE} \
    --policy-arn ${POLICY_ARN} > /dev/null 2>&1

   echo $?
}

function flush_inactive_policy_versions {
  local POLICY_NAME=$1
  local POLICY_ARN="${POLICY_ARN_BASE}/${POLICY_NAME}"

  for VERSION_ID in $(aws iam list-policy-versions \
    --profile $AWS_PROFILE \
    --policy-arn $POLICY_ARN \
    --output json \
    --query 'Versions[?IsDefaultVersion==`false`]' | jq '.[].VersionId' | sed 's/"//g')
  do
    echo "[+] delete policy version: ${POLICY_NAME}/${VERSION_ID}"
    aws iam delete-policy-version \
      --profile ${AWS_PROFILE} \
      --policy-arn ${POLICY_ARN} \
      --version-id ${VERSION_ID} 
  done
}

# a policy can have at most 5 versions - after that the request will fail
function update_policy_version {
  local POLICY_NAME=$1
  local POLICY_DOCUMENT_PATH=$2
  local POLICY_ARN="${POLICY_ARN_BASE}/${POLICY_NAME}"
  echo "[+] update policy: ${POLICY_NAME}"

  aws iam create-policy-version \
    --profile ${AWS_PROFILE} \
    --policy-arn ${POLICY_ARN} \
    --policy-document "file://${POLICY_DOCUMENT_PATH}" \
    --set-as-default
}

function create_policy_version {
  local POLICY_NAME=$1
  local POLICY_DOCUMENT_PATH=$2
  echo "[+] create policy: ${POLICY_NAME}"

  aws iam create-policy \
    --profile ${AWS_PROFILE} \
    --policy-name ${POLICY_NAME} \
    --policy-document "file://${POLICY_DOCUMENT_PATH}"
}

function setup_policy {
  local POLICY_NAME=$1
  local POLICY_DOCUMENT_PATH="${POLICY_PATH}/${POLICY_NAME}.json"
  echo "[*] POLICY_NAME=${POLICY_NAME}"
  echo "[*] POLICY_DOCUMENT_PATH=${POLICY_DOCUMENT_PATH}"

  [[ -f "$POLICY_DOCUMENT_PATH" ]] || (echo "[-] error: policy not found" && exit 1)

  if [[ $(policy_exists ${POLICY_NAME}) == 0 ]]
  then
    flush_inactive_policy_versions ${POLICY_NAME}
    update_policy_version ${POLICY_NAME} ${POLICY_DOCUMENT_PATH}
  else
    create_policy_version ${POLICY_NAME} ${POLICY_DOCUMENT_PATH}
  fi
}

function delete_policy {
  local POLICY_NAME=$1
  local POLICY_ARN="${POLICY_ARN_BASE}/${POLICY_NAME}"
  echo "[+] delete policy: ${POLICY_NAME}"

  flush_inactive_policy_versions ${POLICY_NAME}

  aws iam delete-policy \
    --profile ${AWS_PROFILE} \
    --policy-arn ${POLICY_ARN}
}

##############################

echo "[+] aws_iam_policy_apply"

echo "[*] ACTION=${PARAM_ACTION}"

case ${PARAM_ACTION} in
  "setup")
    PARAM_POLICY_NAME=${2:?"Missing POLICY_NAME"}

    setup_policy ${PARAM_POLICY_NAME}
  ;;
  "setup-all")
    for POLICY in ${POLICY_PATH}/*.json; do
      # extract policy name from path
      setup_policy $(basename ${POLICY} | cut -f 1 -d '.')
    done
  ;;
  "list")
    aws iam list-policies \
      --profile ${AWS_PROFILE} | jq --arg POLICY_PREFIX "$POLICY_PREFIX" '.Policies[] | select(.PolicyName | startswith($POLICY_PREFIX))'
  ;;
  "delete")
    PARAM_POLICY_NAME=${2:?"Missing POLICY_NAME"}

    delete_policy ${PARAM_POLICY_NAME}
  ;;
  *)
    echo "ERROR: unknown command"
    exit 1
  ;;
esac

echo "[-] aws_iam_policy_apply"
