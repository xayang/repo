#!/usr/bin/env bash
set -euxo pipefail

echo "[+] notify_slack"

PARAM_ACTION=${1:?"Missing ACTION"}
PARAM_PROJECT=${2:?"Missing PROJECT"}
PARAM_ENVIRONMENT=${3:?"Missing ENVIRONMENT"}
PARAM_VERSION=${4:-"HEAD"}
PARAM_REASON=${5:-"None given"}

if [ "${PARAM_ACTION}" = "end" ]; then
  if [ "${CODEBUILD_BUILD_SUCCEEDING}" -eq 1 ]; then
    PARAM_ACTION="success"
  else
    PARAM_ACTION="failed"
  fi
fi

case ${PARAM_ACTION} in
"start")
  SLACK_TEXT=":wave: STARTED"
  SLACK_COLOR="warning"
  ;;
"success")
  SLACK_TEXT=":sunglasses: SUCCEED"
  SLACK_COLOR="good"
  ;;
"failed")
  SLACK_TEXT="(╯°□°）╯︵ ┻━┻ FAILED"
  SLACK_COLOR="danger"
  ;;
esac

payload="{
   'attachments': [{
    'title': 'mw-streams-k8s codebuild for ${PARAM_PROJECT} of cluster ${PARAM_ENVIRONMENT}',
    'text': '${SLACK_TEXT} build by ${CODEBUILD_INITIATOR} with bootstrap version *${PARAM_VERSION}* with reason *${PARAM_REASON}*',
    'color': '${SLACK_COLOR}',
    'title_link': '${CODEBUILD_BUILD_URL}'}]}"

curl -X POST -H 'Content-type: application/json' --data "${payload}" https://hooks.slack.com/services/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

echo "[-] notify_slack"
