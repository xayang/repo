#!/bin/bash

set -euo pipefail

CURRENT_PATH=$(cd "$(dirname "${BASH_SOURCE[0]}")"; pwd -P)
cd ${CURRENT_PATH}

##############################

PARAM_ACTION=${1:?"Missing ACTION"}
# example "mw-REPOSITORY_NAME"
PARAM_REPOSITORY=${2:?"Missing REPOSITORY"}

ROOT_PATH="${CURRENT_PATH}/.."
TEMPLATE_PATH="${ROOT_PATH}/scripts/aws/cloud-formation"

AWS_REGION="us-east-1"
AWS_PROFILE="hbc-integration"
STACK_NAME="ecr-stack-${PARAM_REPOSITORY}"
REPOSITORY_NAME="${AWS_PROFILE}/${PARAM_REPOSITORY}"

##############################

echo "[+] aws_ecr_apply"

echo "[*] ACTION=${PARAM_ACTION}"
echo "[*] STACK_NAME=${STACK_NAME}"
echo "[*] REPOSITORY_NAME=${REPOSITORY_NAME}"

case ${PARAM_ACTION} in
  "create")
    aws cloudformation create-stack \
      --profile ${AWS_PROFILE} \
      --stack-name ${STACK_NAME} \
      --template-body "file://${TEMPLATE_PATH}/ecr.template" \
      --parameters ParameterKey=repositoryName,ParameterValue=${REPOSITORY_NAME}
  ;;
  "list-images")
    aws ecr list-images \
      --region ${AWS_REGION} \
      --profile ${AWS_PROFILE} \
      --repository-name ${REPOSITORY_NAME} | jq '.imageIds | sort_by(.imageTag) | reverse | .[].imageTag'
  ;;
  "delete")
    aws cloudformation delete-stack \
      --profile ${AWS_PROFILE} \
      --stack-name "ecr-stack-${PARAM_REPOSITORY}"
  ;;
  *)
    echo "ERROR: unknown command"
    exit 1
  ;;
esac

echo "[-] aws_ecr_apply"
