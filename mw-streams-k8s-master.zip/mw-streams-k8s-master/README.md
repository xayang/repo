# mw-streams-k8s

[![Build Status][travis-image]][travis-url]

[travis-image]: https://travis-ci.com/saksdirect/mw-streams-k8s.svg?token=RVKEmjUFydGqtsrvTQn6&branch=master
[travis-url]: https://travis-ci.com/saksdirect/mw-streams-k8s

## Documentation

* [Setup](docs/setup.md) - How to setup an EKS cluster and bootstrap the infrastructure
* [Argo CD](docs/argocd.md) - How to setup an Argo CD Application on the cluster
* [Travis](docs/travis.md) - How to setup Travis to access ECR
* [IRSA](docs/irsa.md) - How to setup IAM Roles for Service Accounts
* [observe](docs/observe.md) namespace
* [kafka](docs/kafka.md) namespace

TODO
* [ArgoCD Authentication through Okta](docs/argocd-auth.md) - Okta Oauth2 server overview and application specific Helm Template parameters to configure ArgoCD RBAC
* [External DNS](docs/external-dns.md) - How to configure an ASG and Route53 cname to a Service endpoint
* [AppGate](docs/appgate.md) - Required to access **ANY** ip/http endpoint address in the AWS account

---

TODO

* [ ] tune ALL resources e.g. CPU, Memory, Volumes `SFCC1-138`
* [ ] add `targetRevision` or [helm version](https://github.com/argoproj/argo-cd/issues/1145) on every applications
* [ ] add observability (review old gitops repository and charts)
    * scraping Kafka Connect metrics [SFCC1-749](https://hbcdigital.atlassian.net/browse/SFCC1-749)
    * dashboards: global and app specific
    * alert: global and app specific e.g. pod crash, disk space
    * slack integration and dedicated channel for environment
    * add external-dns + service + appgate for: prometheus, grafana, alertmanager, kibana, cerebro
* [ ] investigate if is possible to prevent deleting `applications` and `argocd-config`
* [ ] rename `kafka-connect-operator` >>> `kafka-connector-operator` (old)
* [ ] use strimzi-kafka-connect - `SFCC1-260`
* [ ] PR to strimzi-kafka-topic-operator to manage multiple namespaces
* [ ] move generated cluster definition `scripts/clusters` inside the cluster itself and pull it everytime
* [ ] manage versions for different environments - `SFCC1-626`, `SFCC-627`
* [ ] fix IAM serviceAccount token timeout - `SFCC1-612`
    * possible solution: add init container and schedule cronjob to run `aws sts` to refresh token
* [ ] manage `phoenix-travis` user, `phoenix/travisci/iam-credentials` secrets and IAM policies using CloudFormation
    * policy ECR `arn:aws:iam::aws:policy/AmazonEC2ContainerRegistryPowerUser`
    * policy S3 `arn:aws:iam::280550751197:policy/HbcdPhoenixTravisS3` with restricted buckets
* [ ] create release notes every time a tag is pushed
    * [example](https://blogs.sap.com/2018/06/22/generating-release-notes-from-git-commit-messages-using-basic-shell-commands-gitgrep/) of how get a list of all the commits since last tag
    * [manul](https://github.community/t5/How-to-use-Git-and-GitHub/How-to-create-full-release-from-command-line-not-just-a-tag/td-p/6895) release notes
    * or using GitHub actions create a draft
        * https://github.com/actions/create-release
        * https://github.com/marketplace/actions/release-drafter
        * https://github.com/softprops/action-gh-release
        * https://github.com/marketplace/actions/release-notes-generator-action
* [ ] refactor scripts and export in a common script `AWS_REGION` and `AWS_PROFILE` so that they are defined in a single place

<!--

https://medium.com/faun/aws-eks-and-pods-sizing-per-node-considerations-964b08dcfad3
https://github.com/saksdirect/hbc-common-k8s/tree/master/docs/iam

-->
